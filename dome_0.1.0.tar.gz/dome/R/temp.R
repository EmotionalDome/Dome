data = read.csv("C:/Users/junhy/Documents/one/data/kcb/seminar/data/kcb_sdg_self_emply_all.csv")
data = read.csv("C:/Users/junhy/Documents/one/data/kcb/seminar/data/kcb_sdg_agg_mart_all.csv")
self.var.rvn = function(data){

  na.rm.sd = function(x){
    return(sd(x, na.rm = TRUE))
  }

  na.mean = function(x){
    return(mean(x, na.rm = TRUE))
  }

  vol.rvn = self.vol.rvn(data = data)

  rvn = as.matrix(self.rvn(data = repr, month = TRUE))
  sic_clsfy = rvn[, 1]
  rvn.mat = as.matrix(rvn[, -1])

  w = matrix(rep(1 /length(sic_clsfy), length(sic_clsfy)))

  if (! is.numeric(rvn.mat)){
    rvn.mat = as.numeric(rvn.mat)
  }

  # correlation mat
  mat = matrix(zoo::na.locf(rvn.mat), nrow = length(sic_clsfy), byrow = FALSE)
  corr = cor(t(mat), method = "spearman")






  # returns mat
  returns = apply(apply(mat, 1, function(x) log(x) - log(lag(x))), 2,
                  function(x) na.mean(x))

  sigma = apply(mat, 1, function(x) na.rm.sd(log(x) - log(lag(x))))
  diag(corr) = sigma

  var = round((returns * 1.645 * sqrt(12) * dim(t(w) %*% corr %*% w)) * 100, 2)

  output = as.data.frame(cbind(sic_clsfy, var))

  return(output)
}

df %>%
  ggplot(aes(x = vol, y = ret)) +
  geom_point(shape = 25, color = "blue", size = 1) +
  theme_minimal() +
  geom_hline(yintercept = 0, color = "red", linetype = "dashed", size = 1) +
  geom_vline(xintercept = na.mean(vol), color = "red", linetype = "dashed", size = 1) +
  ggtitle("") +
  xlab("Volatility") +
  ylab("Returns") +
  geom_text(label = rownames(df), alpha = 0.5)

gini = function(data){

  data = kcb.check(data)

  n = dim(data)[1]

  for (i in 1:n){
      G = (1/n) * ((n + 1 - 2) * (sum(n + 1 - i) * data$avg_icm)
                   / sum(data$avg_icm))
  }

  return(G)
}

G = function (x, corr = FALSE, na.rm = TRUE)
{
  if (!na.rm && any(is.na(x)))
    return(NA_real_)
  x = as.numeric(na.omit(x))
  n = length(x)
  x = sort(x)
  G = sum(x * 1L:n)
  G = 2 * G/sum(x) - (n + 1L)

  if (corr)
    G/(n - 1L)
  else G/n
}
